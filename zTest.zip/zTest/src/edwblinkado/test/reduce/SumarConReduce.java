package edwblinkado.test.reduce;

import java.util.ArrayList;
import java.util.List;

public class SumarConReduce {
    public static void main(String[] args) {

        List<Integer> gastos = new ArrayList<Integer>();

        gastos.add(100);
        gastos.add(200);
        gastos.add(300);

        // Recibe 2 par�metros: un acumulador como primero y un elemento como segundo

        gastos.stream().reduce((acumulador, numero) -> {
            return acumulador + numero;
        }).ifPresent(System.out::println);

        System.out.println("*********************************************");

        // Todav�a lo podemos simplificar m�s ya que podr�amos delegar en la clase Integer y en su
        // reference method de sum que realiza la misma operaci�n.

        gastos.stream().reduce(Integer::sum).ifPresent(System.out::println);

        System.out.println("*********************************************");

    }
}
