package edwblinkado.test.reduce;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import edwblinkado.test.models.Persona;

public class ConcatenarConReduce {
    public static void main(String[] args) {

        List<String> nombres = new ArrayList<String>();

        nombres.add("Edw");
        nombres.add("fok");
        nombres.add("er");

        nombres.stream().reduce(String::concat).ifPresent(System.out::println);

        System.out.println("*********************************************");

        Persona p1 = new Persona("pepe", 30);
        Persona p2 = new Persona("juan", 50);
        Persona p3 = new Persona("ana", 40);

        List<Persona> lista = Arrays.asList(p1, p2, p3);

        String nuevaCadena =
            lista.stream()
                .map(Persona::getNombre)
                .collect(Collectors.joining(", ", "(", ")"));

        // En este caso lo que hemos hecho es usar la funci�n map para transformar la lista de
        // objetos en una lista de Strings con los nombres. Una vez que tenemos esta lista de
        // Streams nos queda realizar la operaci�n de collect y agruparlos todos utilizando tres
        // par�metros el primero es el divisor entre elementos �,� . El segundo es el �(� de inicio
        // y el �ltimo el �)� de fin.

        System.out.println(nuevaCadena);

    }
}
