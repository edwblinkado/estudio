package edwblinkado.test.utils;

import java.util.function.Predicate;

import edwblinkado.test.models.Libro;

public class LibroUtils {
    public static Predicate<Libro> filtroCategoria(String categoria) {
        return (Libro l) -> {
            return l.getCategoria().equals(categoria);
        };
    }

    public static boolean buenosLibros(Libro libro) {

        Predicate<Libro> p1 = (Libro l) -> l.getCategoria().equals("ciencia ficcion");
        Predicate<Libro> p2 = (Libro l) -> l.getCategoria().equals("fantasia");
        Predicate<Libro> p3 = (Libro l) -> l.getPaginas() >= 700;
        Predicate<Libro> ptotal = p1.or(p2).and(p3);

        // Ejemplo con negate: predicado5=predicado4.or(predicado3).negate();

        return ptotal.test(libro);
    }
}
