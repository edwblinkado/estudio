package edwblinkado.test.arrays;

import java.util.Arrays;

public class ArraysToStream {

    public static void main(String[] args) {

        String[] cadenas = {"hello", "my", "name", "is", "cecilio"};
        System.out.println(
            Arrays.stream(cadenas).mapToInt(String::length).average().getAsDouble());

        // 1 Hemos convertido el array en un stream
        // 2 Hemos mapeado la propiedad length para convertir el Stream en un Stream de n�meros.
        // 3 Despu�s hemos invocado la propiedad average para calcular la media
        // 4 Finalmente se usa el m�todo get para obtener un resultado.
        
    }
}
