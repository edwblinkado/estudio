package edwblinkado.test.service;

import edwblinkado.test.api.Calculadora;

public class CalculadoraSuma implements Calculadora {

    @Override
    public double operacion(double numero1, double numero2) {

        return numero1 + numero2;
    }

}
