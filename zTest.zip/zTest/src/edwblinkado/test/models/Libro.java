package edwblinkado.test.models;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * Class Description
 * 
 * @author eRiveRa
 *
 */
public class Libro {

    String titulo;
    String categoria;
    Integer paginas;
    List<Capitulo> capitulos = new ArrayList<Capitulo>();

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public Integer getPaginas() {
        return paginas;
    }

    public void setPaginas(Integer paginas) {
        this.paginas = paginas;
    }

    public Libro(String titulo) {
        super();
        this.titulo = titulo;
    }

    public Libro(String titulo, String categoria, Integer paginas) {
        super();
        this.titulo = titulo;
        this.categoria = categoria;
        this.paginas = paginas;
    }

    public void addCapitulo(Capitulo c) {

        capitulos.add(c);

    }

    public Optional<Capitulo> buscarCapitulo(String nombre) {

        for (Capitulo c : capitulos) {
            if (c.getNombre().equals(nombre)) {

                return Optional.of(c);
            }

        }
        return Optional.empty();

    }

}
