package edwblinkado.test.models;

public class Compra {

    private int id;
    private double importe;

    public Compra(int id, double importe) {
        super();
        this.id = id;
        this.importe = importe;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public double getImporte() {
        return importe;
    }

    public void setImporte(double importe) {
        this.importe = importe;
    }

    public double getImporteIVA() {

        return this.importe * 1.21;
    }

    public static boolean esCaro(Compra c) {

        if (c.getImporteIVA() > 150) {
            return true;
        } else {
            return false;
        }
    }

}
