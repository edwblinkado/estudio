package edwblinkado.test.maps;

import java.util.ArrayList;
import java.util.DoubleSummaryStatistics;
import java.util.List;

import edwblinkado.test.models.Persona;

public class MetodosUtilesParaNumerosConMap {

    public static void main(String[] args) {

        Persona p1 = new Persona("pedro", 20);
        Persona p2 = new Persona("juan", 25);
        Persona p3 = new Persona("ana", 30);

        List<Persona> lista = new ArrayList<Persona>();
        lista.add(p1);
        lista.add(p2);
        lista.add(p3);

        lista.stream().map(Persona::getEdad).reduce((a, b) -> a + b).ifPresent(System.out::println);

        int total = lista.stream().mapToInt(Persona::getEdad).sum();
        System.out.println(total);

        lista.stream().mapToDouble(Persona::getEdad).average().ifPresent(System.out::println);
        lista.stream().mapToInt(Persona::getEdad).max().ifPresent(System.out::println);
        lista.stream().mapToInt(Persona::getEdad).min().ifPresent(System.out::println);

        
        //estadisticas tiene todos los m�todos disponibles, aqu� solo puse averge y max
        DoubleSummaryStatistics estadisticas =
            lista.stream().mapToDouble(Persona::getEdad).summaryStatistics();
        System.out.println(estadisticas.getAverage());
        System.out.println(estadisticas.getMax());
    }
}
