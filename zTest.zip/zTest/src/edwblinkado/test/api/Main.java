package edwblinkado.test.api;

import java.util.StringJoiner;

public class Main {

    public static void main(String[] args) {

        // String boleta = "00718B075907628";
        //
        // String boletaEnmascarada = boleta.replaceAll("(\\d{3})(\\d{2})(\\w*)",
        // "$1-$2-$3");
        //
        // System.out.println(boletaEnmascarada);

        String descripcion = "descripcion";
        String referencia = null;

        String adenda = isNullPlusBullet(descripcion, referencia);

        System.out.println(adenda);

        // List<Developer> listDevs = getDevelopers();
        //
        // System.out.println("Before Sort");
        // for (Developer developer : listDevs) {
        // System.out.println(developer);
        // }
        //
        // // sort by age
        // Collections.sort(listDevs, new Comparator<Developer>() {
        // @Override
        // public int compare(Developer o1, Developer o2) {
        // return o1.getAge() - o2.getAge();
        // }
        // });
        //
        // System.out.println("After Sort");
        // for (Developer developer : listDevs) {
        // System.out.println(developer);
        // }
        //
        // }
        //
        // private static List<Developer> getDevelopers() {
        //
        // List<Developer> result = new ArrayList<Developer>();
        //
        // result.add(new Developer("mkyong", new BigDecimal("70000"), 33));
        // result.add(new Developer("alvin", new BigDecimal("80000"), 20));
        // result.add(new Developer("jason", new BigDecimal("100000"), 10));
        // result.add(new Developer("iris", new BigDecimal("170000"), 55));
        //
        // return result;

    }

    static String isNullPlusBullet(String stringToValidate, String secondStringToValidate) {

        String s1 = stringToValidate;
        String s2 = secondStringToValidate;

        StringJoiner sj = new StringJoiner("*");

        if (null != s1) {
            sj.add(s1);
        }

        if (null != s2) {
            sj.add(s2);
        }

        return sj.toString();

    }

}
