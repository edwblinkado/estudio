package edwblinkado.test.api;

public interface Calculadora {

    public double operacion(double numero1, double numero2);

}
