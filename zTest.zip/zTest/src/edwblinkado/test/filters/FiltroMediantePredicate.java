package edwblinkado.test.filters;

import edwblinkado.test.models.Factura;
import edwblinkado.test.models.LineaFactura;

public class FiltroMediantePredicate {
    public static void main(String[] args) {

        Factura f = new Factura();
        f.setNumero(1);
        f.setConcepto("miscompras");
        f.addLinea(new LineaFactura(1, "turron", 3));
        f.addLinea(new LineaFactura(1, "turron", 5));
        f.addLinea(new LineaFactura(1, "turron", 3));
        f.addLinea(new LineaFactura(1, "jamon", 5));
        f.addLinea(new LineaFactura(1, "jamon", 4));

        System.out.println(f.total());
        System.out.println(f.total(l -> l.getConcepto().equals("turron")));

    }
}
