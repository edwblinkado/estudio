package edwblinkado.test.filters;

import java.util.Arrays;
import java.util.List;

import edwblinkado.test.models.Compra;

public class FiltroMedianteMetodosDeLaClase {
    public static void main(String[] args) {

        Compra c1 = new Compra(1, 100);
        Compra c2 = new Compra(2, 130);
        Compra c3 = new Compra(3, 130);

        List<Compra> misCompras = Arrays.asList(c1, c2, c3);

        misCompras.stream().map(c -> c.getImporte() * 1.21).filter(i -> i > 150).reduce(Double::sum)
            .ifPresent(System.out::println);

        System.out.println("*********************************************");

        misCompras.stream().map(Compra::getImporteIVA).filter(i -> i > 150).reduce(Double::sum)
            .ifPresent(System.out::println);

        System.out.println("*********************************************");

        misCompras.stream().filter(Compra::esCaro).map(Compra::getImporteIVA).reduce(Double::sum)
            .ifPresent(System.out::println);

    }

}
