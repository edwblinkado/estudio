package edwblinkado.test.filters;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

import edwblinkado.test.models.Libro;
import edwblinkado.test.utils.LibroUtils;

public class Filtros {
    public static void main(String[] args) {

        Libro l = new Libro("El se�or de los anillos", "fantasia", 1100);
        Libro l2 = new Libro("El Juego de Ender", "ciencia ficcion", 500);
        Libro l3 = new Libro("La fundacion", "ciencia ficcion", 500);
        Libro l4 = new Libro("Los pilares de la tierra", "historica", 1200);
        Libro l5 = new Libro("Edwfoker es tu padre", "ciencia ficcion", 9999);
        List<Libro> lista = Arrays.asList(l, l2, l3, l4, l5);

        lista.stream().filter(libro -> libro.getPaginas() > 1000).map(libro -> libro.getTitulo())
            .forEach(System.out::println);

        System.out.println("*********************************************");

        lista.stream().filter(LibroUtils.filtroCategoria("ciencia ficcion"))
            .map(libro -> libro.getTitulo()).forEach(System.out::println);

        System.out.println("*********************************************");

        lista.stream().filter(LibroUtils::buenosLibros).map(Libro::getTitulo)
            .forEach(System.out::println);

        System.out.println("*********************************************");

        // Creating a Stream of Strings
        Stream<String> stream = Stream.of("Geeks", "fOr",
            "GEEKSQUIZ", "GeeksforGeeks");

        // Using Stream filter(Predicate predicate)
        // to get a stream consisting of the
        // elements having UpperCase Character
        // at index 1
        stream.filter(str -> Character.isUpperCase(str.charAt(1)))
            .forEach(System.out::println);

        System.out.println("*********************************************");

        // Creating a Stream of Strings
        Stream<String> stream2 = Stream.of("Geeks", "foR",
            "GeEksQuiz", "GeeksforGeeks");

        // Using Stream filter(Predicate predicate)
        // to get a stream consisting of the
        // elements ending with s
        stream2.filter(str -> str.endsWith("s"))
            .forEach(System.out::println);

        System.out.println("*********************************************");

        // Creating a list of Integers
        List<Integer> list = Arrays.asList(3, 4, 6, 12, 20);

        // Using Stream filter(Predicate predicate)
        // to get a stream consisting of the
        // elements that are divisible by 5
        list.stream().filter(num -> num % 5 == 0).forEach(System.out::println);
    }

}
