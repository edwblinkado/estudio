package edwblinkado.test.sort;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import edwblinkado.test.models.Persona;

public class OrdenarConComparator {

    public static void main(String[] args) {

        ArrayList<Persona> milista = new ArrayList<Persona>();
        milista.add(new Persona("Miguel"));
        milista.add(new Persona("Alicia"));
        milista.add(new Persona("Edwin"));
        milista.add(new Persona("Adolfo"));

        Collections.sort(milista,
            // Es le misme pere mes berete
            // (Persona p1, Persona p2) -> p1.getNombre().compareTo(p2.getNombre()));
            (p1, p2) -> p1.getNombre().compareTo(p2.getNombre()));

        for (Persona p : milista) {
            System.out.println(p.getNombre());
        }

        System.out.println("*********************************************");

        Persona p1 = new Persona("pedro", "perez", "gomez");
        Persona p2 = new Persona("angel", "alvarez", "zamora");
        Persona p3 = new Persona("ana", "perez", "jimenez");
        Persona p4 = new Persona("ana", "sainz", "jimenez");
        Persona p5 = new Persona("maria", "alvarez", "alvarez");

        List<Persona> lista = Arrays.asList(p1, p2, p3, p4, p5);

        // Comparar usando 1 solo parametro

        // lista.sort((pa,pb)->pa.getNombre().compareTo(pb.getNombre()));
        // lista.forEach(System.out::println);
        // lista.sort((pa,pb)->pa.getApellido1().compareTo(pb.getApellido1()));
        // lista.forEach(System.out::println);

        Comparator<Persona> comparadorA =
            (pa, pb) -> pa.getApellido1().compareTo(pb.getApellido1());
        Comparator<Persona> comparadorB =
            comparadorA.thenComparing((pa, pb) -> pa.getApellido2().compareTo(pb.getApellido2()));
        lista.sort(comparadorB);

        lista.forEach(System.out::println);
    }
}
