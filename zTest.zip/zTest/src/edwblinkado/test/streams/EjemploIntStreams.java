package edwblinkado.test.streams;

import java.util.stream.IntStream;

public class EjemploIntStreams {

    public static void main(String[] args) {

        IntStream it = IntStream.of(1, 2, 3, 4, 5, 6);
        it.forEach(System.out::println);

        System.out.println("*********************************************");

        IntStream it2 = IntStream.range(0, 100);
        it2.forEach(System.out::println);

        System.out.println("*********************************************");

        System.out.println(IntStream.range(0, 100).sum());

        System.out.println("*********************************************");

    }
}
