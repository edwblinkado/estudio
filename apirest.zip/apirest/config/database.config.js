module.exports = {
    url: 'mongodb://express:earc1721...edwbd@localhost:27017/exampledb'
}