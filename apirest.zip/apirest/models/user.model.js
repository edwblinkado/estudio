const moongose = require('mongoose');

const UserSchema = moongose.Schema({
    _name: String,
    _age: String,
    _sex: String
});

module.exports = moongose.model('User', UserSchema);