const User = require('../models/user.model.js');

//create a new user impl
exports.create = (req, res) => {
    // Validate res
    if(!req.body.content) {
      return res.status(400).send({
          message: "User content can not be empty"
      });
  }

  // Create a User
  const user = new User({
      _name: req.body._name || "Unnamed User", 
      _age: req.body._age
  });

  // Save User in the database
  user.save()
  .then(data => {
      res.send(data);
  }).catch(err => {
      res.status(500).send({
          message: err.message || "Some error occurred while creating the User."
      });
  });
};

//get all users impl
exports.findAll = (req, res) => {
    User.find()
    .then(users => {
        res.send(users);
    })
    .catch(error => {
        res.status(500).send({
            message:error.message
        })
    })
};

//get a single user impl
exports.findOne = (req, res) => {
  User.findById(req.params.userId)
  .then(user => {
      if(!user) {
          return res.status(404).send({
              message: "User not found with id " + req.params.userId
          });            
      }
      res.send(user);
  }).catch(err => {
      if(err.kind === 'ObjectId') {
          return res.status(404).send({
              message: "User not found with id " + req.params.userId
          });                
      }
      return res.status(500).send({
          message: "Error retrieving user with id " + req.params.userId
      });
  });
};