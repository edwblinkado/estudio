const express = require('express');
const bodyParser = require('body-parser');


//create an app of express
const app = express();

// parse requests of content-type - application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({
    extended: true
}))

// parse requests of content-type - application/json
app.use(bodyParser.json())

//configuring the database
const dbConfig = require('./config/database.config.js');
const moongose = require('mongoose');

moongose.Promise = global.Promise;

//conection to database
moongose.connect(dbConfig.url, {

    useNewUrlParser: true

}).then(() => {

    console.log("Successfully connected to the database");

}).catch(err => {

    console.log('Could not connect to the database. Exiting now...', err);
    process.exit();

});

require('./routes/user.routes.js')(app);

app.listen(3000, () => console.log("Server listening!"));
