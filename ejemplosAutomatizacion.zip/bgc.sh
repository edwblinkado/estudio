#!/bin/bash

###############################################################################
## automatic exit from bash shell script on error
set -e
##
###############################################################################
UPSTREAM_URL=$BGP_GITLAB_URL/devops/gitlab/groups/bgp-bel/comercial/main
BRANCH_DEFAULT=dev

COMMAND="$1"
PROJECTS_TO_REVIEW=( )
C_BLUE='\033[0;34m'
C_RED='\033[0;31m'
C_CYAN='\033[0;36m'
C_BCYAN='\033[1;36m'
C_YELLOW='\033[1;33m'
C_PURPLE='\033[0;35m' 
C_NC='\033[0m' # No Color
###############################################################################
PROJECTS_JAVA_SERVICE=(\
  "ws-api-services"\
  "common-service"\
  "user-service"\
  "report-service"\
  "product-service"\
  "account-service"\
  "security-device-service"\
  "transaction-service"\
  "transfer-service"\
  "commercial-reports-service"\
  "performed-transactions-service"\
  "authorization-service"\
  "check-service"\
  "collector-payment-service"\
  "contact-us-service"\
  "main-account-service"\
  "recharge-service"\
  "charge-service"\
  "notification-service"\
  "company-data-info-service"\
  "pin-service"\
  "special-reports-service"\
  "stock-market-confirmations-service"\
  "messages-service"\
  "manage-users-service"\
  "credit-letters-service"\
  "ach-service"\
 )

PROJECTS_JAVA_WEB=(\
  "transfer-web"\
  "performed-transactions-web"\
  "authorization-web"\
  "bgo-login-web"\
  "check-images-web"\
  "collector-payment-web"\
  "contact-us-web"\
  "credit-card-statement-web"\
  "dashboard-account-web"\
  "dashboard-next-transactions-web"\
  "favorites-web"\
  "http-status"\
  "international-reports-web"\
  "login-expire"\
  "login-web"\
  "main-account-web"\
  "overseas-transfer-web"\
  "product-info-web"\
  "received-payments-reports-web"\
  "recharge-web"\
  "scheduled-transactions-web"\
  "security-device-web"\
  "security-info-web"\
  "startup-environment"\
  "charge-web"\
  "notifications-config-web"\
  "company-data-info-web"\
  "request-card-pin-web"\
  "pos-reports-web"\
  "stock-market-confirmations-web"\
  "messages-web"\
  "effective-communication-web"\
  "line-of-credit-reports-web"\
  "manage-users-web"\
  "user-config-web"\
  "loan-reports-web"\
  "credit-letters-web"\
  "ach-web"\
  "discrepancies-web"\
  "etesa-web"\
 )

PROJECTS_OTHERS=(\
  "bgp-theme"\
  "has-annotation-plugin"\
 )
###############################################################################
function git-update-portal-service {
   project=$1
  if [ ! -d "$project" ]; then
    echo ""
    echo -e "${C_YELLOW}>>> Clonando: $project ${C_NC}"
    echo ""
    echo $UPSTREAM_URL/$project.git
    echo ""
    git clone $UPSTREAM_URL/$project.git
    cd $project
    echo ""
    echo -e "${C_CYAN}>>> Desplegando: $project ${C_NC}"
    echo ""
    gradle clean install deploy
    cd ..
    echo ""
  fi
  cd $project
  changes=$(git diff)
  if [ -n "$changes" ]; then
    PROJECTS_TO_REVIEW+=($project)
    echo ""
    echo -e "${C_RED}>>> *********************************** ${C_NC}"
    echo -e "${C_RED}>>> '$project' tiene cambios. Revisalo manualmente.${C_NC}"
    echo -e "${C_RED}>>> *********************************** ${C_NC}"
  else
    echo ""
    # echo -e "${C_BLUE}>>> Cambiando a Dev: $project ${C_NC}"
    # echo ""
    # git checkout dev
    # echo ""
    echo -e "${C_CYAN}>>> Actualizando: $project ${C_NC}"
    echo ""
    upToDate=$(git pull)
    git pull
      if [ "$upToDate" != "Already up-to-date." ]; then
        echo ""
        echo -e "${C_PURPLE}>>> Desplegando: $project ${C_NC}"
        echo ""
        gradle clean install deploy
      fi
  fi
  cd ..
}

function git-update-portal-web {
   project=$1
  if [ ! -d "$project" ]; then
    echo ""
    echo -e "${C_YELLOW}>>> Clonando: $project ${C_NC}"
    echo ""
    echo $UPSTREAM_URL/$project.git
    echo ""
    git clone $UPSTREAM_URL/$project.git
    cd $project
    echo ""
    echo -e "${C_CYAN}>>> Desplegando: $project ${C_NC}"
    echo ""
    gradle clean deploy
    cd ..
    echo ""
  fi
  cd $project
  changes=$(git diff)
  if [ -n "$changes" ]; then
    PROJECTS_TO_REVIEW+=($project)
    echo ""
    echo -e "${C_RED}>>> *********************************** ${C_NC}"
    echo -e "${C_RED}>>> '$project' tiene cambios. Revisalo manualmente.${C_NC}"
    echo -e "${C_RED}>>> *********************************** ${C_NC}"
  else
    echo ""
    # echo -e "${C_BLUE}>>> Cambiando a Dev: $project ${C_NC}"
    # echo ""
    # git checkout dev
    # echo ""
    echo -e "${C_CYAN}>>> Actualizando: $project ${C_NC}"
    echo ""
    upToDate=$(git pull)
    git pull
      if [ "$upToDate" != "Already up-to-date." ]; then
        echo ""
        echo -e "${C_PURPLE}>>> Desplegando: $project ${C_NC}"
        echo ""
        gradle clean deploy
      fi
  fi
  cd ..
}

function git-update-portal-all {
  for i in "${PROJECTS_OTHERS[@]}"
  do
    git-update-portal-service $i
  done

  for i in "${PROJECTS_JAVA_SERVICE[@]}"
  do
    git-update-portal-service $i
  done

  for i in "${PROJECTS_JAVA_WEB[@]}"
  do
    git-update-portal-web $i
  done

  if [ ${#PROJECTS_TO_REVIEW[@]} != 0 ]; then
    echo ""
    echo -e "${C_RED} Revisa los siguientes modulos ya que contienen cambios sin commit: ${C_NC}"
    for i in "${PROJECTS_TO_REVIEW[@]}"
    do
      echo -e "${C_RED}     * $i${C_NC}"
    done
    echo ""
  fi
}

function deploy-all {
  for i in "${PROJECTS_JAVA_SERVICE[@]}"
  do
    echo -e "\n${C_CYAN}>>> Desplegando: $i${C_NC}"
    cd $i
    gradle clean install deploy -x test
    cd ..
  done

  for i in "${PROJECTS_JAVA_WEB[@]}"
  do
    echo -e "\n${C_CYAN}>>> Desplegando: $i${C_NC}"
    cd $i
    gradle clean deploy -x test
    cd ..
  done
}

function deploy-ws {
  echo -e "\n${C_CYAN}>>> deploy: ws ${C_NC}"
  cd ws-api-services
  git pull
  git clean -fX ./*/src/main/java
  gradle clean install deploy
  cd ..
}

###############################################################################

case "${COMMAND}" in
  update)

  echo "                                                             .."
  echo "                                  ,,,                         MM .M"
  echo "                              ,!MMMMMMM!,                     MM MM  ,."
  echo "      ., .M                .MMMMMMMMMMMMMMMM.,          'MM.  MM MM .M'"
  echo "    . M: M;  M          .MMMMMMMMMMMMMMMMMMMMMM,          'MM,:M M'!M'"
  echo "   ;M MM M: .M        .MMMMMMMMMMMMMMMMMMMMMMMMMM,         'MM'...'M"
  echo "    M;MM;M :MM      .MMMMMMMMMMMMMMMMMMMMMMMMMMMMMM.       .MMMMMMMM"
  echo "    'M;M'M MM      MMMMMM  MMMMMMMMMMMMMMMMM  MMMMMM.    ,,M.M.'MMM'"
  echo -e "     MM'MMMM      MMMMMM ${C_YELLOW}@@${C_NC} MMMMMMMMMMMMMMM ${C_YELLOW}@@${C_NC} MMMMMMM.'M''MMMM;MM'"
  echo "    MM., ,MM     MMMMMMMM  MMMMMMMMMMMMMMMMM  MMMMMMMMM      '.MMM"
  echo "    'MM;MMMMMMMM.MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM.      'MMM"
  echo "     ''.'MMM'  .MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM       MMMM"
  echo "      MMC      MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM.      'MMMM"
  echo "     .MM      :MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM''MMM       MMMMM"
  echo -e "     MMM      :M  'MMMMMMMMMMMMM.${C_RED}MMMMM${C_NC}.MMMMMMMMMM'.MM  MM:M.    'MMMMM"
  echo "    .MMM   ...:M: :M.'MMMMMMMMMMMMMMMMMMMMMMMMM'.M''   MM:MMMMMMMMMMMM'"
  echo "   AMMM..MMMMM:M.    :M.'MMMMMMMMMMMMMMMMMMMM'.MM'     MM''''''''''''"
  echo "   MMMMMMMMMMM:MM     'M'.M'MMMMMMMMMMMMMM'.MC'M'     .MM"
  echo "    '''''''''':MM.       'MM!M.'M-M-M-M'M.'MM'        MMM"
  echo "               MMM.            'MMMM!MMMM'            .MM"
  echo "                MMM.             '''   ''            .MM'"
  echo "                 MMM.                               MMM'"
  echo -e "                  MMMM            ${C_RED},.J.JJJJ.${C_NC}       .MMM'"
  echo -e "                   MMMM.       ${C_RED}'JJJJJJJ'JJJM${C_NC}   CMMMMM"
  echo -e "                     MMMMM.    ${C_RED}'JJJJJJJJ'JJJ${C_NC} .MMMMM'"
  echo -e "                       MMMMMMMM.'  ${C_RED}'JJJJJ'JJ${C_NC}MMMMM'"
  echo -e "                         'MMMMMMMMM${C_RED}'JJJJJ JJJJJ${C_NC}'"
  echo -e "                            ''MMMMMM${C_RED}JJJJJJJJJJ${C_NC}'"
  echo -e "                                    ${C_RED}'JJJJJJJJ${C_NC}'     ${C_PURPLE}BEL Comercial!${C_NC} " 

    echo -e "\n${C_BCYAN}========== ACTUALIZANDO PORTAL ========${C_NC}"
    git-update-portal-all
    echo ""
  ;;

  deploy)
    echo -e "\n${C_BCYAN}========== DESPLEGANDO TODOS LOS MODULOS  ========${C_NC}"
    deploy-all
    echo ""
  ;;

  ws)
    echo -e "\n${C_BCYAN}========== DESPLEGANDO WS  ========${C_NC}"
    deploy-ws
    echo ""
  ;;


  *)

    echo ""
    if [ "$1" ]; then
      echo -e "${C_RED}Opcion invalida $1${C_NC}"
      echo ""
    fi
    echo -e "${C_CYAN} Opciones : ${C_NC}"
    echo -e "\t${C_PURPLE}update${C_NC} - Actualiza y solo despliega si hay cambios"
    echo -e "\t${C_PURPLE}deploy${C_NC} - Despliega todos los modulos"
    echo -e "\t${C_PURPLE}ws${C_NC} - Despliega ws"
    echo -e ""
    exit 1
esac
exit 0
