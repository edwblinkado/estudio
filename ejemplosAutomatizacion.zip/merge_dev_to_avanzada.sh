#!/bin/bash

# REMOTE_URL="http://devops/gitlab/bgp-bel/personal/main"

for dir in */ ; do
  cd $dir
  project=${dir::-1}
  if [ -d ".git" ]; then

C_BLUE='\033[0;34m'
C_RED='\033[0;31m'
C_CYAN='\033[0;36m'
C_BCYAN='\033[1;36m'
C_YELLOW='\033[1;33m'
C_PURPLE='\033[0;35m' 
C_NC='\033[0m' # No Color

    echo -e "${C_BCYAN}>>> Checkout a dev: $project ${C_NC}"
    git checkout dev
     echo -e "${C_BCYAN}>>> Actualizando dev: $project ${C_NC}"
    git pull
    echo -e "${C_PURPLE}>>> Checkout avanzada: $project ${C_NC}"
    git checkout avanzada
     echo -e "${C_PURPLE}>>> Actualizando avanzada: $project ${C_NC}"
    git pull
    echo -e "${C_YELLOW}>>> Merge con MAIN origin/dev: $project ${C_NC}"
    git merge dev
    echo -e "${C_YELLOW}>>> Push de los cambios: $project ${C_NC}"
    git push avanzada HEAD:dev

  else
    echo "-- El directorio ${project} no es un proyecto Git."
    echo -e "${C_RED}>>> El directorio ${project} no es un proyecto Git. ${C_NC}"
  fi
  cd ..
done

echo -e "\nFinalizada la actualización de remotos."
