#!/bin/bash

# REMOTE_URL="http://devops/gitlab/bgp-bel/comercial/main"
NO_UNIFICADO="/c/Users/eRiveRa/comercial/"
UNIFICADO="/c/Users/eRiveRa/app/"

for dir in */ ; do
  cd $dir
  project=${dir::-1}
  if [ -d ".git" ]; then
    echo "Actualizando el proyecto ${project}..."
  	find . -name .settings -type d | xargs rm -rf
		find . -name .gradle -type d | xargs rm -rf
    # find . -name src -type d | xargs rm -rf
    find . -name build -type d | xargs rm -rf
    find . -name bin -type d | xargs rm -rf
    find . -name .classpath -type f -delete
    find . -name .project -type f -delete
    mkdir /c/Users/eRiveRa/Desktop/Test/nuevo/${project}
    cp -R . /c/Users/eRiveRa/Desktop/Test/nuevo/${project}
  else
    echo "-- El directorio ${project} no es un proyecto Git."
  fi
  cd ..
done

echo -e "\nFinalizado el script."
