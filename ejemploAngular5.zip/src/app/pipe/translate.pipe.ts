import { Pipe, PipeTransform } from '@angular/core';
import { TranslateService } from '../services/translate.service';
import { DomSanitizer } from "@angular/platform-browser";
import { log } from 'util';

@Pipe({name: 'translate'})
export class Translate implements PipeTransform {
  
  constructor(
    private _tService: TranslateService,
    private _sanitizer: DomSanitizer) { }

  transform(key:String, args:any) {
    var value = this._tService.getValue(key, args);
    console.log("Valor: ", value);
    return value;
    
    // return function(key:String, args:any) {
    //   var value = this._tService.getValue(key, args);
    //   console.log(value);
    }
  }
