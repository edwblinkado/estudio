import {Component, OnInit} from "@angular/core";

//services
import { ContactService } from './services/contact.service';

@Component({
	selector: 'app',
	templateUrl: 'app.html',
  providers: [ContactService]
})

export class AppComponent implements OnInit {

	//variables
	public clientType: String;
	public companies: any[];
	public categories: any[];

	constructor(
		private _contactService: ContactService)
	{ }

	ngOnInit() {
		this.getCompanies();
		this.getCategories();
	}

	getCompanies(){
		this._contactService.getCompanies().subscribe(
			result => {
				this.companies = result.companies;
				this.clientType = result.clientType;
			},
			error => {
				console.log(<any>error);
			}
		);
	}

	getCategories(){
		this._contactService.getCategories().subscribe(
			result => {
				this.categories = result;
			},
			error => {
				console.log(<any>error);
			}
		);
	}
}
