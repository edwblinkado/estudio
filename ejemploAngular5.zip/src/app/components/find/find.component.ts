import { Component } from '@angular/core';

@Component({
	selector: 'find',
	templateUrl: 'find.html'
})
export class FindComponent {

	constructor(){
    
	}

	ngOnInit(){

	}
}