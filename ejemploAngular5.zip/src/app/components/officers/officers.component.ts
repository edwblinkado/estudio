import { Component, Input } from '@angular/core';

//services

@Component({
	selector: 'officers',
	templateUrl: 'officers.html',
})

export class OfficersComponent {

	@Input() public companies: any[];

	constructor() {}

  ngOnInit() {}
}