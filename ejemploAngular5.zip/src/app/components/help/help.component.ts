import { Component } from '@angular/core';

@Component({
	selector: 'help',
	templateUrl: 'help.html'
})
export class HelpComponent {

	constructor(){
    
	}

	ngOnInit(){

	}
}