import { Component, Input } from "@angular/core";

//services
import { ContactService } from '../../services/contact.service';

//globals
import { GLOBAL } from '../../services/global';

//models
import { ContactUsMessage } from '../../models/contactUsMessage';

@Component({
    selector: "contactForm",
    templateUrl: "contactForm.html",
    providers: [ContactService]
})

export class ContactFormComponent {

    //variables
    @Input() public clientType: String;
    @Input() public companies: any[];
    @Input() public categories: any[];
    public contactUsMessage={body:"", category:"", subject:"", company:""};
    public toSend: ContactUsMessage;

    //globals
    public groupType: String;
    public companyType: String;

    //forms
    public messageSent = false;

    constructor(
        private _contactService: ContactService)
     { }

    ngOnInit() {
        this.groupType = GLOBAL.groupType;
        this.companyType = GLOBAL.companyType;
    }

    sendMessage(contactForm) {

        if(contactForm.form.valid){
            
            this.messageSent = true;    
            this.toSend = new ContactUsMessage(this.contactUsMessage);

            this._contactService.sendMessage(this.toSend).subscribe(
                response => {
					console.log(response);
				},
				error => {
					console.log(<any>error);
				}
			);

        } else {
            if(contactForm.form.controls['company']){
              contactForm.form.controls['company'].markAsTouched();
            }
            contactForm.form.controls['category'].markAsTouched();
            contactForm.form.controls['subject'].markAsTouched();
            contactForm.form.controls['body'].markAsTouched();
        }

    }
}
