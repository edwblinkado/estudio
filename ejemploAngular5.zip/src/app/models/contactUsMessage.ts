export class ContactUsMessage{
	constructor(
		public contactUsMessage: {
		body: String,
		category: String,
		subject:String
		}
	){}
}