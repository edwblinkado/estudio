export var GLOBAL = {
	url: '/o/api/jetray/contact-us/',
	groupType: 'G',
	companyType: 'C',
};
