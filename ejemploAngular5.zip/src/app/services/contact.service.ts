import { Injectable } from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import 'rxjs/add/operator/map';
import { Observable } from 'rxjs/Observable';
import { GLOBAL } from './global';
import { ContactUsMessage } from '../models/contactUsMessage';

@Injectable()
export class ContactService{
	public url: string;

	constructor(
		public _http: Http
	){
		this.url = GLOBAL.url;
	}

	getCompanies(){
		return this._http.get(this.url+'client-type').map(res => res.json());
	}

	getCategories(){
		return this._http.get(this.url+'catalog/categories').map(res => res.json());
	}

	sendMessage(toSend: ContactUsMessage){
		// let json = JSON.stringify(toSend);
		// let params = "{contactUsMessage: " + toSend + "}";
		// let params = "{\"contactUsMessage\":{\"category\":\"P\",\"subject\":\"123\",\"body\":\"456\"}}";
		let params = toSend;
		let headers = new Headers({'Content-type':'application/json'});

		return this._http.post(this.url+'send-message', params, {headers: headers})
			.map(res => res.json());
	}
}
