import { Injectable } from '@angular/core';

@Injectable()
export class TranslateService {

  constructor() { }

  private interpolateArgs:any = function(string:String, args:any) {
    return string.replace(/{(\d+)}/g, (match, argIndex) => {
      var arg = args[argIndex];
      return arg === undefined ? match : arg;
    }); 
  };

  public getValue:any = function(key, args) {
    var value = "BGP_i18n[key]";

    if(args)
      value = this.interpolateArgs(value, args);

    return value;
  }

  public interpolate:any = function(string:String, args:any) {
    if(args)
      string = this.interpolateArgs(string, args);
      
      string = string.replace(/\$(.+?)\$/g, (match, key) => {
        var value = this.getValue(key);
        return value === undefined ? match : value;
      });
      
    return string;
  };

}