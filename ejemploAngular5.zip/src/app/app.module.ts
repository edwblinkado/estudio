import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from "@angular/http";
import { CommonModule } from '@angular/common';
import { Translate } from './pipe/translate.pipe';
import { TranslateService } from './services/translate.service'
import { ContactFormComponent } from "./components/contactForm/contactForm.component";
import { OfficersComponent } from "./components/officers/officers.component";
import { HelpComponent } from "./components/help/help.component";
import { FindComponent } from "./components/find/find.component";
import { FooterComponent } from "./components/footer/footer.component";
import { AppComponent } from './app.component';

@NgModule({
    imports: [
        BrowserModule,
        FormsModule,
        HttpModule,
        CommonModule,
    ],
    declarations: [
        AppComponent,
        Translate,
        ContactFormComponent,
        OfficersComponent,
        HelpComponent,
        FindComponent,
        FooterComponent
    ],
    providers: [TranslateService],
    bootstrap: [AppComponent]
})
export class AppModule {}
